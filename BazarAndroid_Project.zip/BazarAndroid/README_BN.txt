বাজারের তালিকা + মেস হিসাব — Android Studio Project

এই ZIP-এ আপনার সর্বশেষ index_mess_added.html ফাইলটি Android WebView অ্যাপের ভিতরে রাখা হয়েছে।

গুরুত্বপূর্ণ:
- এটি Android Studio source project; এখনো তৈরি করা signed AAB নয়।
- AAB তৈরি করতে Android Studio, Android SDK 36, JDK 17 এবং Gradle 8.13/Android Gradle Plugin 8.13.0 লাগবে।
- প্রথমবার Gradle ও Android SDK ডাউনলোড করতে ইন্টারনেট লাগবে।

AAB বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন: https://developer.android.com/studio
2. ZIP Extract করুন। Android Studio > Open > BazarAndroid ফোল্ডার সিলেক্ট করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। SDK 36 চাইলে SDK Manager থেকে Android 16 / API 36 ইনস্টল করুন।
4. Build > Generate Signed Bundle / APK নির্বাচন করুন।
5. Android App Bundle নির্বাচন করুন > Next।
6. Create new দিয়ে নিজের keystore বানিয়ে নিরাপদে সংরক্ষণ করুন। Password হারাবেন না; ভবিষ্যৎ আপডেটের জন্য এটি দরকার।
7. release নির্বাচন করে Finish চাপুন।
8. AAB পাওয়া যাবে: app/build/outputs/bundle/release/app-release.aab

নোট:
- এই প্রজেক্টের applicationId: com.rakib.bazartalika । Play Store-এ প্রথমবার প্রকাশের আগে স্থায়ী package ID ঠিক করে নিন; পরে বদলালে সেটি আলাদা অ্যাপ হয়ে যাবে।
- WebView-এর localStorage এই অ্যাপের নিজস্ব ডেটা স্টোরেজ। পুরনো WebIntoApp ইনস্টলের ডেটা নতুন প্যাকেজে স্বয়ংক্রিয়ভাবে আসবে না।
- Google Play Console-এ প্রকাশের আগে অ্যাপটি বাস্তব Android ডিভাইসে পরীক্ষা করুন এবং Privacy Policy / Data safety তথ্য সঠিকভাবে পূরণ করুন।
- Google Play Console-এর এককালীন Developer registration fee এবং নতুন Personal account-এর testing/verification শর্ত আলাদা।
